module.exports = {
  setupFilesAfterEnv: ["./tests/jestSetup.js"],
};
