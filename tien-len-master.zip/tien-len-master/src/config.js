export const GAME_SERVER_PORT = 8000;
export const GAME_SERVER_URL = `http://localhost:${GAME_SERVER_PORT}`;
export const WEB_SERVER_URL = "http://localhost:8000";
export const APP_PRODUCTION = true;
export const LOBBY = true;
