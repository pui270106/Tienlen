// src/tests/.eslintrc.js

module.exports = {
  plugins: ["jest"],
  extends: ["plugin:jest/recommended"],
};
